Results of commands do not have proper formatting

Credentials stored in ~/.aws/Credentials
Needs to be updated every few hours to be do changes

Deploy Code::
powershell run {serverless deploy}
ensure is in serverless.yml directory










:::Information:::

telegramID: lagibagusbot 
telegram bot name: lagibagus
